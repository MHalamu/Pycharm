from Commands.command_interface import ICommand
from VoiceUtils.text_to_speech import TextToSpeech
from Commands.voice_commands import VoiceCommand
from Commands.relay_commands import EnableRelayCommand
from Controllers.pins_assignment import RELAY_MAP


class AssignRelayCommand(ICommand):

    def __init__(self, gpio_controller, voice_command, text_to_speech, voice_recognizer, invoker):
        self.gpio_controller = gpio_controller
        self.voice_command = voice_command
        self.text_to_speech = text_to_speech
        self.voice_recognizer = voice_recognizer
        self.invoker = invoker
        self.relay_number = None

    def get_relay_number(self):
        self.voice_command.execute()
        relay_number = self.voice_recognizer.listen_for_voice()
        try:
            int(relay_number)
        except ValueError:
            raise Exception("Relay is not a number. Try again") # Dodac taka komende
        assignment_command = VoiceCommand("assign_relay_%s" % relay_number,
                                          "You are now assigning relay number %s" % relay_number)
        self.text_to_speech.add_recording(assignment_command)
        assignment_command.execute()

        return relay_number

    def get_new_command_name(self):
        assignment_command = VoiceCommand("assign_name_for_relay_%s" % self.relay_number,
                                          "Please provide a name for command assigned to relay %s" % self.relay_number)
        self.text_to_speech.add_recording(assignment_command)
        assignment_command.execute()

        relay_command_name = self.voice_recognizer.listen_for_voice()

        assignment_command = VoiceCommand("relay_%s_name_replay" % self.relay_number,
                                          "Relay number %s is now assigned as %s" % (self.relay_number,relay_command_name))
        assignment_command.execute()

        turn_on_relay_voice_command = VoiceCommand("enable_relay_%s" % self.relay_number,
                                                   "Turning on %s" % relay_command_name,
                                                   "turn on %s" % relay_command_name)
        self.text_to_speech.add_recording(turn_on_relay_voice_command)

        turn_off_relay_voice_command = VoiceCommand("disable_relay_%s" % self.relay_number,
                                                   "Turning off %s" % relay_command_name,
                                                   "turn off %s" % relay_command_name)
        self.text_to_speech.add_recording(turn_off_relay_voice_command)

        self.invoker.set_command(EnableRelayCommand(
            gpio_controller=self.gpio_controller, pin=RELAY_MAP[int(self.relay_number)],
            voice_command=turn_on_relay_voice_command))
        self.invoker.set_command(EnableRelayCommand(
            gpio_controller=self.gpio_controller, pin=RELAY_MAP[int(self.relay_number)],
            voice_command=turn_off_relay_voice_command))


    def execute(self):
        self.relay_number = self.get_relay_number()
        self.get_new_command_name()


        # a=1
        #
        #
        #
        #
        # voice_command = VoiceCommand("assign_relay_%s" % relay_number,
        #                              "The main door has been unlocked")
        # self.text_to_speech.add_recording(voice_command)

        #
        #
        #
        #
        # self.gpio_controller.on(self.pin) # turn on relay
        # TextToSpeech.play_recording(self.voice_command)


class UnlockCommand(ICommand):

    def __init__(self, gpio_controller, pin, voice_command):
        self.gpio_controller = gpio_controller
        self.pin = pin
        self.voice_command = voice_command

    def execute(self):
        self.gpio_controller.off(self.pin)
        self.voice_command.execute()

