class VoiceCommand(object):
    def __init__(self, recording_name, text):
        self.recording_name = recording_name
        self.text = text


class VoiceCommandsContainer(object):

    GREETING = VoiceCommand("greeting.mp3", "Hello, what can I do for you?")
    CMD_NOT_RECOGNIZED = VoiceCommand("cmd_not_recognized.mp3", "Sorry, I didn't get this. Try again.")
    IS_ANYTHING_ELSE = VoiceCommand("is_anything_else.mp3", "Can I do anything else for you?")
    TURN_ON_LIGHT_KITCHEN = VoiceCommand("Light_on_kitchen.mp3", "Turning on light in the kitchen.")
    TURN_OFF_LIGHT_KITCHEN = VoiceCommand("Light_off_kitchen.mp3", "Turning off light in the kitchen.")
