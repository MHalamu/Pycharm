import os
from gtts import gTTS


class TextToSpeech(object):

    RECORDINGS_PATH = "Recordings/"

    def __init__(self, voice_recognizer, ready_for_voice_event):
        self.text_to_recording_map = {} # To chyba w ogolnie nie jest potrzebne
        self.voice_recognizer = voice_recognizer
        self.ready_for_voice_event = ready_for_voice_event

    def add_recording(self, command):
        self.text_to_recording_map[command.recording_name] = gTTS(command.text)
        self.text_to_recording_map[command.recording_name].save(self.RECORDINGS_PATH + command.recording_name)

    def remove_recording(self, command):
        self.text_to_recording_map.pop(command.recording_name, None)

    def play_recording(self, command):
        print(command.recording_name)
        import time
        #self.voice_recognizer.stop_bg_listener()
        #self.ready_for_voice_event.clear()
        #print("### CLEARING EVENT###")
        os.system("mpg321 %s%s" % ("Recordings/", command.recording_name))
        #time.sleep(2)
        #self.voice_recognizer.start_background_listener()
        #self.ready_for_voice_event.set()
        #print("### SETTING EVENT###")
