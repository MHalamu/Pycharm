import speech_recognition as sr
from voice_commands import VoiceCommandsContainer
from text_to_speech import TextToSpeech
import time
from voice_recognizer import VoiceRecognizer
import logging
from Commands.light_commands import LightOffKitchenCommand, LightOnKitchenCommand
from Controllers.light_controller import LightController
from Invoker.invoker import Invoker
from VoiceAssist.voice_assist import VoiceAssist
import queue

logging.basicConfig(level=logging.INFO)


def _initialize_text_to_speech(voice_recognizer, ready_for_voice_event):
    logging.info('Initializing text_to_speech module...')
    text_to_speech = TextToSpeech(voice_recognizer, ready_for_voice_event)
    for voice_command in [VoiceCommandsContainer.GREETING, VoiceCommandsContainer.CMD_NOT_RECOGNIZED,
                          VoiceCommandsContainer.IS_ANYTHING_ELSE, VoiceCommandsContainer.TURN_ON_LIGHT_KITCHEN,
                          VoiceCommandsContainer.TURN_OFF_LIGHT_KITCHEN]:
        text_to_speech.add_recording(voice_command)

    return text_to_speech


def _initialize_voice_recognizer(voice_queue, ready_for_voice_event):
    logging.info('Initializing voice recognizer...')
    voice_recognizer = VoiceRecognizer(mic_index=0, voice_queue=voice_queue, ready_for_voice_event=ready_for_voice_event)  #, text_to_speech=text_to_speech)
    #voice_recognizer.start_background_listener()
    return voice_recognizer

def _initialize_commands_module(text_to_speech):
    logging.info('Initializing commands module...')

    light_controller = LightController()

    invoker = Invoker()
    invoker.set_command(LightOnKitchenCommand.CMD_NAME, LightOnKitchenCommand(light_controller=light_controller, pin=8, text_to_speech=text_to_speech))
    invoker.set_command(LightOffKitchenCommand.CMD_NAME, LightOffKitchenCommand(light_controller=light_controller, pin=8, text_to_speech=text_to_speech))

    return invoker



while False:
    time.sleep(1)

    try:
        # start listening in the background (note that we don't have to do this inside a `with` statement)
        #stop_listening = recognizer.listen_in_background(mic, callback)
        # `stop_listening` is now a function that, when called, stops background listening

        # # do some unrelated computations for 5 seconds
        # for _ in range(50): time.sleep(
        #     0.1)  # we're still listening even though the main thread is doing other things
        #
        # # calling this function requests that the background listener stop listening
        # stop_listening(wait_for_stop=False)
        #
        # # do some more unrelated things
        while True: time.sleep(
            1)  # we're not listening anymore, even though the background thread might still be running for a second or two while cleaning up and stopping


        # #listen_in_background
        #
        # print("waiting for audio...")
        # audio = recognizer.listen(source, timeout=3, phrase_time_limit=3)
        # recognized_speech = recognizer.recognize_google(audio)
        # print(recognized_speech)
        # if any((text in recognized_speech.lower() for text in ["hello pie", "hello pipe", "hello by", "hello vine", "Hello pine"])):
        #     text_to_speech.play_recording(VoiceCommandsContainer.GREETING)
        #
        #     while True:
        #         audio = recognizer.listen(source, timeout=10, phrase_time_limit=5)
        #         recognized_speech = recognizer.recognize_google(audio)
        #         print(recognized_speech)
        #         if recognized_speech.lower() in ["turn on light in the kitchen"]:
        #             text_to_speech.play_recording(VoiceCommandsContainer.TURN_ON_LIGHT_KITCHEN)
        #
        #             text_to_speech.play_recording(VoiceCommandsContainer.IS_ANYTHING_ELSE)
        #             audio = recognizer.listen(source, timeout=10, phrase_time_limit=5)
        #             recognized_speech = recognizer.recognize_google(audio)
        #             print(recognized_speech)
        #             if recognized_speech == "no":
        #                 break
        #         else:
        #             text_to_speech.play_recording(VoiceCommandsContainer.CMD_NOT_RECOGNIZED)



    except sr.UnknownValueError:
        pass

    except sr.WaitTimeoutError:
        pass
        print("WaitTImeoutError")


def main():
    import threading
    voice_queue = queue.Queue()
    ready_for_voice_event = threading.Event()
    ready_for_voice_event.set()

    voice_recognizer = _initialize_voice_recognizer(voice_queue, ready_for_voice_event)
    text_to_speech = _initialize_text_to_speech(voice_recognizer, ready_for_voice_event)


    invoker = _initialize_commands_module(text_to_speech)


    voice_assist = VoiceAssist(invoker, text_to_speech, voice_queue, ready_for_voice_event, voice_recognizer)
    voice_assist.run()










if __name__ == '__main__':
    main()





