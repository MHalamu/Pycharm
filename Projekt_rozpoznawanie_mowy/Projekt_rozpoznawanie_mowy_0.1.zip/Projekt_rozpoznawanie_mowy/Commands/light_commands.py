from Commands.command_interface import ICommand
from Projekt_rozpoznawanie_mowy.text_to_speech import TextToSpeech
from Projekt_rozpoznawanie_mowy.voice_commands import VoiceCommandsContainer


class LightOnKitchenCommand(ICommand):

    CMD_NAME = "LightOnKitchen"

    def __init__(self, light_controller, pin, text_to_speech):
        self.light_controller = light_controller
        self.pin = pin
        self.text_to_speech = text_to_speech

    def execute(self):
        self.light_controller.on(self.pin)
        self.text_to_speech.play_recording(VoiceCommandsContainer.TURN_ON_LIGHT_KITCHEN)

class LightOffKitchenCommand(ICommand):

    CMD_NAME = "LightOffKitchen"

    def __init__(self, light_controller, pin, text_to_speech):
        self.light_controller = light_controller
        self.pin = pin
        self.text_to_speech = text_to_speech

    def execute(self):
        self.light_controller.off(self.pin)
        self.text_to_speech.play_recording(VoiceCommandsContainer.TURN_ON_LIGHT_KITCHEN)
