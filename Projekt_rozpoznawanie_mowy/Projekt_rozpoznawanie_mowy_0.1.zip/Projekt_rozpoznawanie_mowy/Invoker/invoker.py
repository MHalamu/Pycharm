class Invoker(object):
    def __init__(self):
        self.command_to_button_map = {}
        self.voice_to_command_map = {"turn on light in the kitchen": "LightOnKitchen"}

    def execute(self, text_command):
        print(self.command_to_button_map)
        self.command_to_button_map[self.voice_to_command_map[text_command]].execute()

        # moze tutaj powinien cos mowic?

    def set_command(self, command_name, command):
        self.command_to_button_map[command_name] = command
        print("Setting command: %s" % command_name)
