import speech_recognition as sr
from voice_commands import VoiceCommandsContainer
import threading

class VoiceRecognizer(object):

    PHRASE_TIME_LIMIT = 5

    def __init__(self, mic_index):#, text_to_speech):
        self.recognizer = sr.Recognizer()
        #self.text_to_speech = text_to_speech
        self.mic = sr.Microphone(device_index=mic_index)
        with self.mic as source:
            self.recognizer.adjust_for_ambient_noise(source)


    def _callback(self, recognizer, audio):



        ### Tutaj zrobic observer pattern ktory bedzie notifykowal modul komand ze nowa komenda sie pojawila\
        ### i tam to jakos bedzie parsowane i bedzie wykonywana jakas akcja w zaleznosci od komendy.

        # received audio data, now we'll recognize it using Google Speech Recognition
        try:
            # for testing purposes, we're just using the default API key
            # to use another API key, use `r.recognize_google(audio, key="GOOGLE_SPEECH_RECOGNITION_API_KEY")`
            # instead of `r.recognize_google(audio)`
            print("WAITING FOR SETTING EVENT")
            is_set = self.ready_for_voice_event.is_set()
            print("is_set %s" % is_set)
            if not is_set:
                print("event is not set")
                return

            print("EVENT SET")
            text = recognizer.recognize_google(audio)
            print("Google Speech Recognition thinks you said " + recognizer.recognize_google(audio))
            self.voice_queue.put_nowait(text)

        except sr.UnknownValueError:
            print("Google Speech Recognition could not understand audio")
            #self.text_to_speech.play_recording(VoiceCommandsContainer.CMD_NOT_RECOGNIZED)  # to moze byc aktywne dopiero po poczatkowym "Hello Pi"
        except sr.RequestError as e:
            print("Could not request results from Google Speech Recognition service; {0}".format(e))

    # def start_background_listener(self):
    #     self.stop_bg_listener = self.recognizer.listen_in_background(self.mic, self._callback, self.PHRASE_TIME_LIMIT)

    def listen_for_command(self):
        while True:
            print("waiting for voice...")
            try:
                with self.mic as source:
                    audio = self.recognizer.listen(source, 1, self.PHRASE_TIME_LIMIT)
                recognized_speech = self.recognizer.recognize_google(audio)
                print(recognized_speech)
                return recognized_speech
            #self.voice_queue.put_nowait(text)

            except sr.UnknownValueError:
                print("Google Speech Recognition could not understand audio")
                # self.text_to_speech.play_recording(VoiceCommandsContainer.CMD_NOT_RECOGNIZED)  # to moze byc aktywne dopiero po poczatkowym "Hello Pi"
            except sr.RequestError as e:
                print("Could not request results from Google Speech Recognition service; {0}".format(e))
            except sr.WaitTimeoutError:
                print("Tiemout")


