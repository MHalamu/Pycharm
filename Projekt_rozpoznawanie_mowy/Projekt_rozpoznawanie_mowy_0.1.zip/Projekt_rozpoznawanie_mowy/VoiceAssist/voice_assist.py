from Commands.light_commands import LightOffKitchenCommand, LightOnKitchenCommand

import time
from voice_commands import VoiceCommandsContainer

class VoiceAssist(object):
    def __init__(self, invoker, text_to_speech, voice_queue, ready_for_voice_event, voice_recognizer):
        self.invoker = invoker
        self.text_to_speech = text_to_speech
        self.voice_queue = voice_queue
        self.ready_for_voice_event = ready_for_voice_event
        self.voice_recognizer = voice_recognizer

    def _wait_for_initial_activity(self):
        while True:
            print("Waiting for init activity")
            voice_text = self.voice_recognizer.listen_for_command()
            #voice_text = self.voice_queue.get()
            if any((text in voice_text.lower() for text in
                    ["hello pie", "hello pipe", "hello by", "hello vine", "Hello pine"])):
                self.text_to_speech.play_recording(VoiceCommandsContainer.GREETING)


                return
            # self.invoker.execute(LightOnKitchenCommand.CMD_NAME)
            # self.invoker.execute(LightOffKitchenCommand.CMD_NAME)

    def _wait_for_command_activity(self):
        while True:
            print("Waiting for command")
            #voice_command = self.voice_queue.get()
            voice_command = self.voice_recognizer.listen_for_command()
            # self.invoker.execute(LightOnKitchenCommand.CMD_NAME)
            # self.invoker.execute(LightOffKitchenCommand.CMD_NAME)

            return voice_command

    def run(self):
        while True:
            self._wait_for_initial_activity()

            while True:
                voice_command = self._wait_for_command_activity()
                if voice_command == "no":
                    break


                print(voice_command)
                try:
                    self.invoker.execute(voice_command)
                    self.text_to_speech.play_recording(VoiceCommandsContainer.IS_ANYTHING_ELSE)

                except KeyError:
                    pass

            # teraz jezeli jakas komenda wypadnie to powinien byc zawolany invoker i ja wykonac
            # nastepnie pytanie czy mozna cos jeszcze zrobic i od nowa. Moze sie okazac
            # ze dana komenda to nie tylk on/off ale ze np przypisanie przekaznika, czyli jeszcze
            # cos trzeba powiedziec. To wszystko powinno byc zrobione w ramach command zeby tutaj
            # bylo jak najczysciej
